<?php if (isset($component)) { $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7 = $component; } ?>
<?php $component = App\View\Components\ClientLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ClientLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="h-[200px] w-[200px] bg-white p-0">
        <img src="build/assets/qr.png" alt="">
    </div>
    <a class="mt-10 inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150" href="/surprise-wheel">Surprise press</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7)): ?>
<?php $component = $__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7; ?>
<?php unset($__componentOriginal19c4e483e5c865bc7c9b689f46d76ac7); ?>
<?php endif; ?>
<?php /**PATH E:\Projects\Full-Stack\raaef_event\resources\views/qr.blade.php ENDPATH**/ ?>